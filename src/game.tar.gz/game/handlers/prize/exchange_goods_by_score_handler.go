package prize

import (
	"code.google.com/p/goprotobuf/proto"
	domainPrize "game/domain/prize"
	domainUser "game/domain/user"
	"game/server"
	"github.com/golang/glog"
	//"gopkg.in/mgo.v2/bson"
	"pb"
	"time"
	"util"
)

func ExchangeGoodsByScoreHandler(m *pb.ServerMsg, sess *server.Session) []byte {
	player := domainUser.GetPlayer(sess.Data)

	msg := &pb.MsgExchangeScoreGoodsReq{}
	err := proto.Unmarshal(m.GetMsgBody(), msg)
	if err != nil {
		glog.Error(err)
		return nil
	}

	res := &pb.MsgExchangeScoreGoodsRes{}

	itemId := int(msg.GetItemId())
	goods, ok := domainPrize.GetExchangeGoodsManager().GetExchangeGoods(itemId)
	if !ok {
		glog.Error("找不到兑换配置itemId:", itemId)
		res.Code = pb.MsgExchangeScoreGoodsRes_FAILED.Enum()
		return server.BuildClientMsg(m.GetMsgId(), res)
	}

    info := domainUser.GetUserFortuneManager().GetCharmExchangeInfo(player.User.UserId, itemId)
    if info >= goods.MaxCount && goods.MaxCount != -1 {
		glog.Error("兑换次数到达上限userId:", player.User.UserId, "|count=", info)
		res.Code = pb.MsgExchangeScoreGoodsRes_FAILED.Enum()
		return server.BuildClientMsg(m.GetMsgId(), res)
    }

	if !domainUser.GetUserFortuneManager().ConsumeCharm(player.User.UserId, goods.NeedScore) {
		glog.Error("消耗魅力失败userId:", player.User.UserId, " needCharm:", goods.NeedScore)
		res.Code = pb.MsgExchangeScoreGoodsRes_LACK_SCORE.Enum()
		return server.BuildClientMsg(m.GetMsgId(), res)
	}

    domainUser.GetUserFortuneManager().UpdateUserFortune(player.User.UserId)
    util.MongoLog_CharmExchange(goods.NeedScore)
    util.MongoLog_CharmPool(-goods.NeedScore)

	/*if msg.GetItemId() == 9 {
		// 四倍卡
		prizeMail := &domainPrize.PrizeMail{}
		prizeMail.UserId = player.User.UserId
		prizeMail.MailId = bson.NewObjectId().Hex()
		prizeMail.Content = "魅力兑换"
		prizeMail.ItemType = int(pb.MagicItemType_FOURFOLD_GOLD)
		prizeMail.ItemCount = 1

		player.PrizeMails.AddPrizeMail(prizeMail)

		mailMsg := &pb.MsgGetPrizeMailListRes{}
		mailMsg.Mails = append(mailMsg.Mails, prizeMail.BuildMessage())

		player.SendToClient(int32(pb.MessageId_GET_PRIZE_MAIL_LIST), mailMsg)

		res.Code = pb.MsgExchangeScoreGoodsRes_OK.Enum()
		return server.BuildClientMsg(m.GetMsgId(), res)
	}
	if msg.GetItemId() == 10 {
		// 禁比卡
		prizeMail := &domainPrize.PrizeMail{}
		prizeMail.UserId = player.User.UserId
		prizeMail.MailId = bson.NewObjectId().Hex()
		prizeMail.Content = "魅力兑换"
		prizeMail.ItemType = int(pb.MagicItemType_PROHIBIT_COMPARE)
		prizeMail.ItemCount = 1

		player.PrizeMails.AddPrizeMail(prizeMail)

		mailMsg := &pb.MsgGetPrizeMailListRes{}
		mailMsg.Mails = append(mailMsg.Mails, prizeMail.BuildMessage())

		player.SendToClient(int32(pb.MessageId_GET_PRIZE_MAIL_LIST), mailMsg)

		res.Code = pb.MsgExchangeScoreGoodsRes_OK.Enum()
		return server.BuildClientMsg(m.GetMsgId(), res)
	}
	if msg.GetItemId() == 11 {
		// 换牌卡
		prizeMail := &domainPrize.PrizeMail{}
		prizeMail.UserId = player.User.UserId
		prizeMail.MailId = bson.NewObjectId().Hex()
		prizeMail.Content = "魅力兑换"
		prizeMail.ItemType = int(pb.MagicItemType_REPLACE_CARD)
		prizeMail.ItemCount = 1

		player.PrizeMails.AddPrizeMail(prizeMail)

		mailMsg := &pb.MsgGetPrizeMailListRes{}
		mailMsg.Mails = append(mailMsg.Mails, prizeMail.BuildMessage())

		player.SendToClient(int32(pb.MessageId_GET_PRIZE_MAIL_LIST), mailMsg)

		res.Code = pb.MsgExchangeScoreGoodsRes_OK.Enum()
		return server.BuildClientMsg(m.GetMsgId(), res)
	}*/

	l := &domainPrize.ExchangeGoodsLog{}
	l.UserId = player.User.UserId
	l.UserName = player.User.UserName
	l.ItemId = itemId
	l.IsShipped = false
	l.ShippingAddressName = player.User.ShippingAddressName
	l.ShippingAddressPhone = player.User.ShippingAddressPhone
	l.ShippingAddressAddress = player.User.ShippingAddressAddress
	l.ShippingAddressZipCode = player.User.ShippingAddressZipCode

	l.Time = time.Now()
	err = domainPrize.SaveExchangeGoodsLog(l)
	if err != nil {
		res.Code = pb.MsgExchangeScoreGoodsRes_FAILED.Enum()
		glog.Error("保存物品兑换记录失败l:", l)
		return server.BuildClientMsg(m.GetMsgId(), res)
	} else {
		res.Code = pb.MsgExchangeScoreGoodsRes_OK.Enum()
	}

    domainUser.GetUserFortuneManager().UpdateCharmExchangeInfo(player.User.UserId, itemId, 1)

	return server.BuildClientMsg(m.GetMsgId(), res)
}
