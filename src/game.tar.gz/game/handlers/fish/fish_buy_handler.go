package fish

import (
    "github.com/golang/glog"
    "net/http"
    "encoding/json"
	domainUser "game/domain/user"
	"time"
	"config"
)


type JsonBuyObj struct {
    FishType        int
    Count           int
}

type BuyRetInfo struct {
    IsOk      string
    Reason    string
}

func FishBuyHandler(w http.ResponseWriter, r *http.Request) {
    r.ParseForm()
    w.Header().Set("Access-Control-Allow-Origin", "*")

    token := r.FormValue("access_token")
    userId := r.FormValue("user_id")
    json_obj := r.PostFormValue("obj")

    retInfo := BuyRetInfo{}
    retInfo.IsOk = "failed"

	if userId == "" || token == "" || json_obj == "" {
	    glog.Error("FishBuyHandler Param Error.", json_obj, userId, token)
	    retInfo.Reason = "接口参数错误"
        ret_str, _ := json.Marshal(retInfo)
		w.Write([]byte(ret_str))
		return
	}

	obj := JsonBuyObj{}
    err := json.Unmarshal([]byte(json_obj), &obj)
    if err != nil {
        glog.Error(err)
	    retInfo.Reason = "接口参数格式错误"
        ret_str, _ := json.Marshal(retInfo)
        w.Write([]byte(ret_str))
        return
    }

	f, ok := domainUser.GetUserFortuneManager().GetUserFortune(userId)
	if !ok {
        glog.Error("GetUserFortune error.")
	    retInfo.Reason = "获取用户信息失败"
        ret_str, _ := json.Marshal(retInfo)
        w.Write([]byte(ret_str))
        return
    }

    if f.FishToken.Token != token || int(time.Now().Unix()) - f.FishToken.TimeStamp > 7200 {
        glog.Infof("Token error. %s, %d", f.FishToken.Token, f.FishToken.TimeStamp)
	    retInfo.Reason = "token已过期"
        ret_str, _ := json.Marshal(retInfo)
        w.Write([]byte(ret_str))
        return
    }

    Cfish, _ := config.GetFishConfigManager().GetFishConfig(obj.FishType)
    price := int64(Cfish.Price * obj.Count)
    if f.Gold < price {
        glog.Infof("gold error. %d, %d", price, f.Gold)
	    retInfo.Reason = "您的金币不足，请充值"
        ret_str, _ := json.Marshal(retInfo)
        w.Write([]byte(ret_str))
        return
    }

    _, ok = domainUser.GetUserFortuneManager().EarnGold(userId, -price, "买鱼")
    if ok {
        domainUser.GetUserFortuneManager().AddFish(userId, userId, obj.FishType, obj.Count)
        domainUser.GetUserFortuneManager().SaveUserFortune(userId)
    } else {
        glog.Infof("EarnGold error.")
	    retInfo.Reason = "系统错误，请稍候尝试"
        ret_str, _ := json.Marshal(retInfo)
        w.Write([]byte(ret_str))
        return
    }

    retInfo.IsOk = "success"
    ret_str, _ := json.Marshal(retInfo)
    w.Write([]byte(ret_str))
}