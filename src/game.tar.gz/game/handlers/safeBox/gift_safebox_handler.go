package safeBox

import (
	"code.google.com/p/goprotobuf/proto"
	domainUser "game/domain/user"
	"game/server"
	"github.com/golang/glog"
	"pb"
	"fmt"
)

func GiftSafeBoxHandler(m *pb.ServerMsg, sess *server.Session) []byte {
    glog.Info("GiftSafeBoxHandler in")
	msg := &pb.Msg_GiftGoldSafeBoxReq{}
	err := proto.Unmarshal(m.GetMsgBody(), msg)
	if err != nil {
		glog.Error(err)
		return nil
	}

    userId := msg.GetUserId()
    pwd := msg.GetPwd()
    gold := msg.GetGold()
    toUid := msg.GetToUid()

    res := &pb.Msg_GiftGoldSafeBoxRes{}
    _, tok := domainUser.GetUserFortuneManager().GetUserFortune(toUid)
    if tok {
        _, ok := domainUser.GetUserFortuneManager().EarnGold(toUid, gold, "赠送收取")
        if !ok {
            res.Code = pb.Msg_GiftGoldSafeBoxRes_FAILED.Enum()
            res.Reason = proto.String("赠送失败，请稍候尝试")
            domainUser.GetPlayerManager().SendClientMsg(userId, int32(pb.MessageId_GIFT_GOLD_SAFEBOX), res)
            return nil
        }
    } else {
        _, ok := domainUser.GetUserFortuneManager().AddGold2Mongo(toUid, gold, "赠送收取")
        if !ok {
            res.Code = pb.Msg_GiftGoldSafeBoxRes_FAILED.Enum()
            res.Reason = proto.String("赠送失败，请稍候尝试")
            domainUser.GetPlayerManager().SendClientMsg(userId, int32(pb.MessageId_GIFT_GOLD_SAFEBOX), res)
            return nil
        }
    }

    code, reason, savings, _, log := domainUser.GetUserFortuneManager().UpdateSavings(userId, pwd, -gold, "赠送扣款", toUid)
    if code != 0 {
        res.Code = pb.Msg_GiftGoldSafeBoxRes_FAILED.Enum()
        res.Reason = proto.String(reason)
        domainUser.GetUserFortuneManager().ConsumeGold(toUid, gold, false, "赠送失败，系统回收")
        domainUser.GetPlayerManager().SendClientMsg(userId, int32(pb.MessageId_GIFT_GOLD_SAFEBOX), res)
        return nil
    }

    domainUser.GetUserFortuneManager().SaveUserFortune(toUid)
    domainUser.GetUserFortuneManager().UpdateUserFortune2(toUid, 0)
    res.Code = pb.Msg_GiftGoldSafeBoxRes_OK.Enum()
    res.Savings = proto.Int64(savings)
    logmsg := &pb.BoxLogsDef{}
    logmsg.Reason = proto.String(log.Reason)
    logmsg.Gold = proto.Int64(log.Gold)
    logmsg.Savings = proto.Int64(log.Savings)
    logmsg.Datetime = proto.String(fmt.Sprintf("%d-%d-%d %02d:%02d:%02d",log.DateTime.Year(), log.DateTime.Month(), log.DateTime.Day(), log.DateTime.Hour(), log.DateTime.Minute(), log.DateTime.Second()))
    logmsg.ToUid = proto.String(log.ToUid)
    res.Log = logmsg

    domainUser.GetPlayerManager().SendClientMsg(userId, int32(pb.MessageId_GIFT_GOLD_SAFEBOX), res)
    return nil
}