package pay

import (
	domainPay "game/domain/pay"
	domainUser "game/domain/user"
	"code.google.com/p/goprotobuf/proto"
	"github.com/golang/glog"
	"game/server"
	"pb"
)

func GetPayTokenHandler(m *pb.ServerMsg, sess *server.Session) []byte {
    msg := &pb.Msg_GetPayTokenReq{}
    err := proto.Unmarshal(m.GetMsgBody(), msg)
    if err != nil {
        glog.Error(err)
        return nil
    }

    userId := msg.GetUserId()

    token := domainPay.GetTokenManager().GetToken(userId)
    res := &pb.Msg_GetPayTokenRes{}
    res.Token = proto.String(token)

    domainUser.GetPlayerManager().SendClientMsg(userId, int32(pb.MessageId_GET_PAY_TOKEN), res)

    return nil
}