package cdkey

import (
	"code.google.com/p/goprotobuf/proto"
	domainCDKey "game/domain/cdkey"
	domainUser "game/domain/user"
	"game/server"
	"github.com/golang/glog"
	"pb"
)

func ExchangeCDKeyHandler(m *pb.ServerMsg, sess *server.Session) []byte {
	player := domainUser.GetPlayer(sess.Data)

	msg := &pb.MsgExchangeCodePrizeReq{}
	err := proto.Unmarshal(m.GetMsgBody(), msg)
	if err != nil {
		glog.Error(err)
		return nil
	}

	glog.V(2).Info("==>兑换CDKey:", msg)

	res := &pb.MsgExchangeCodePrizeRes{}

	if msg.GetCode() == "" {
		glog.Error("查找CDKey失败code:", msg.GetCode(), " err:", err)
		res.Code = pb.MsgExchangeCodePrizeRes_FAILED.Enum()
		return server.BuildClientMsg(m.GetMsgId(), res)
	}

	cdKey, err := domainCDKey.FindCDKey(msg.GetCode())
	if err != nil {
		glog.Error("查找CDKey失败code:", msg.GetCode(), " err:", err)
		res.Code = pb.MsgExchangeCodePrizeRes_FAILED.Enum()
		return server.BuildClientMsg(m.GetMsgId(), res)
	}

	if cdKey.Type != 0 && player.CDKeyGainRecord.IsGained(cdKey.Type) {
		glog.Error("userId:", player.User.UserId, " 该类型CDKey已经领取keyType:", cdKey.Type)
		res.Code = pb.MsgExchangeCodePrizeRes_FAILED.Enum()
		return server.BuildClientMsg(m.GetMsgId(), res)
	}

	err = domainCDKey.RemoveCDKey(msg.GetCode())
	if err != nil {
		glog.Error("删除CDKey失败code:", msg.GetCode(), " err:", err)
		res.Code = pb.MsgExchangeCodePrizeRes_FAILED.Enum()
		return server.BuildClientMsg(m.GetMsgId(), res)
	}

	player.CDKeyGainRecord.SetGained(cdKey.Type)

	// 获得奖励
	domainUser.GetUserFortuneManager().EarnFortune(player.User.UserId, int64(cdKey.Gold), cdKey.Diamond, cdKey.Score, false, "cdkey兑换")
	if cdKey.ItemType > 0 && cdKey.ItemCount > 0 {
		if cdKey.ItemType == int(pb.MagicItemType_FOURFOLD_GOLD) {
			domainUser.GetUserFortuneManager().BuyDoubleCard(player.User.UserId, 0, cdKey.ItemCount)
		} else if cdKey.ItemType == int(pb.MagicItemType_PROHIBIT_COMPARE) {
			domainUser.GetUserFortuneManager().BuyForbidCard(player.User.UserId, 0, cdKey.ItemCount)
		} else if cdKey.ItemType == int(pb.MagicItemType_REPLACE_CARD) {
			domainUser.GetUserFortuneManager().BuyChangeCard(player.User.UserId, 0, cdKey.ItemCount)
		}
	}

	domainUser.GetUserFortuneManager().UpdateUserFortune(player.User.UserId)

	res.Code = pb.MsgExchangeCodePrizeRes_OK.Enum()
	res.Gold = proto.Int(cdKey.Gold)
	res.Diamond = proto.Int(cdKey.Diamond)
	res.GameScore = proto.Int(cdKey.Score)
	res.ItemType = proto.Int(cdKey.ItemType)
	res.ItemCount = proto.Int(cdKey.ItemCount)

	return server.BuildClientMsg(m.GetMsgId(), res)
}
