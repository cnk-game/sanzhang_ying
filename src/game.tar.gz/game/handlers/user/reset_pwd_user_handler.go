package user

import (
	"code.google.com/p/goprotobuf/proto"
	domainUser "game/domain/user"
	"game/server"
	"github.com/golang/glog"
	"pb"
	"util"
)

func ResetPwdUserHandler(m *pb.ServerMsg, sess *server.Session) []byte {
	player := domainUser.GetPlayer(sess.Data)

	msg := &pb.Msg_ResetPwdUserReq{}
	err := proto.Unmarshal(m.GetMsgBody(), msg)
	if err != nil {
		glog.Error(err)
		return nil
	}

	res := &pb.Msg_ResetPwdUserRes{}

	userId := msg.GetUserId()
	pwd := msg.GetNewpwd()
	phone := msg.GetPhone()
	code := int(msg.GetCode())

	if pwd == "" || userId == "" {
		glog.Info("===>ResetPwdUserHandler param error., sess:", sess)
		res.Code = pb.Msg_ResetPwdUserRes_FAILED.Enum()
		return server.BuildClientMsg(m.GetMsgId(), res)
	}

	ok := util.CheckVerify(phone, code)
	if !ok {
		glog.Info("===>RegisterHandler ,CheckVerify error, phone:", phone)
		res.Code = pb.Msg_ResetPwdUserRes_FAILED.Enum()
		return server.BuildClientMsg(m.GetMsgId(), res)
	}

	u, err := domainUser.FindByUserId(userId)
	if err != nil {
		glog.Info("===>RegisterHandler ,FindByUserId error, userId:", userId)
		res.Code = pb.Msg_ResetPwdUserRes_FAILED.Enum()
		return server.BuildClientMsg(m.GetMsgId(), res)
	}

    u.Password = genPassword(pwd)
    player.User.Password = genPassword(pwd)
    err = domainUser.SaveUser(u)
    if err != nil {
        glog.Info("保存用户失败err:", err, " user:", u)
		res.Code = pb.Msg_ResetPwdUserRes_FAILED.Enum()
        return server.BuildClientMsg(m.GetMsgId(), res)
    }

    res.Code = pb.Msg_ResetPwdUserRes_OK.Enum()
	return server.BuildClientMsg(m.GetMsgId(), res)
}

