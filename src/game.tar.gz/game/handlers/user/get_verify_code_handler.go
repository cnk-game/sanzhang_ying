package user

import (
	"code.google.com/p/goprotobuf/proto"
	"game/server"
	"github.com/golang/glog"
	"pb"
	"util"
)

func GetVerifyCodeHandler(m *pb.ServerMsg, sess *server.Session) []byte {
	msg := &pb.Msg_GetVerifyCodeReq{}
	err := proto.Unmarshal(m.GetMsgBody(), msg)
	if err != nil {
		glog.Error(err)
		return nil
	}

	res := &pb.Msg_GetVerifyCodeRes{}
	phone := msg.GetPhone()

    ok := util.GetVerify(phone)
    if !ok {
		glog.Info("GetVerifyCodeHandler error, phone=", phone)
    }

    res.IsOk = proto.Bool(ok)
    return server.BuildClientMsg(m.GetMsgId(), res)
}
