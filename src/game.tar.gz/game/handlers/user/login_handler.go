package user

import (
	"code.google.com/p/goprotobuf/proto"
	"config"
	"crypto/md5"
	"fmt"
	domainGame "game/domain/game"
	"game/domain/offlineMsg"
	//	domainPrize "game/domain/prize"
	domainUser "game/domain/user"
	"game/server"
	"github.com/golang/glog"
	mgo "gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"io"
	"math/rand"
	"pb"
	"time"
	"util"
)

const (
	retryTimes       = 5
	retryMillisecond = 500
)

func genPassword(pwd string) string {
	h := md5.New()
	io.WriteString(h, config.ControlKey+pwd)
	return fmt.Sprintf("%x", h.Sum(nil))
}

func LoginHandler(m *pb.ServerMsg, sess *server.Session) []byte {
	msg := &pb.MsgLoginReq{}
	err := proto.Unmarshal(m.GetMsgBody(), msg)
	if err != nil {
		glog.Error(err)
		return nil
	}

	res := &pb.MsgLoginRes{}

	player := domainUser.NewPlayer()

	glog.Info("===>用户登录消息sess:", sess, " msg:", msg)

	if msg.GetUsername() == "" {
		msg.Username = proto.String("skytaox")
	}

	if msg.GetUsername() == "" {
		glog.Info("===>登录无效,username为空sess:", sess)
		return nil
	}

	// 用户名登录
	u, err := domainUser.FindByUserName(msg.GetUsername())
	player.User = u
	glog.Info("==>查找用户username:", msg.GetUsername(), " err:", err, " u:", u)
	if err != nil {
		if err == mgo.ErrNotFound {
			if msg.GetIsSwitchAccount() {
				res.Code = pb.MsgLoginRes_USERNAME_OR_PASSWORD_ERROR.Enum()
				return server.BuildClientMsg(m.GetMsgId(), res)
			}
			nickName := msg.GetNickname()
			if nickName == "" {
				nickName = msg.GetModel()
			}
			if nickName == "" {
				glog.Info("==>登录结果:Nickname不能为空!sess:", sess)
				res.Code = pb.MsgLoginRes_FAILED.Enum()
				return server.BuildClientMsg(m.GetMsgId(), res)
			}
			if msg.GetRobotKey() == config.RobotKey {
				// 机器人
				u.IsRobot = true
				if msg.GetRobotGender() == 0 {
					u.Gender = int(pb.Gender_BOY)
				} else {
					u.Gender = int(pb.Gender_GIRL)
				}
				u.PhotoUrl = msg.GetRobotPhoto()
				u.RobotVipLevel = int(msg.GetRobotVip())
			} else {
				if rand.Float64() < 0.5 {
					u.Gender = int(pb.Gender_BOY)
					u.PhotoUrl = fmt.Sprintf("%v", 6+rand.Int()%3)
				} else {
					u.Gender = int(pb.Gender_GIRL)
					u.PhotoUrl = fmt.Sprintf("%v", 1+rand.Int()%5)
				}
			}
			// 用户不存在，直接创建
			//u.UserId = bson.NewObjectId().Hex()
			u.UserId = domainUser.GetNewUserId()
			u.UserName = msg.GetUsername()
			u.Password = genPassword(msg.GetUserpwd())
			u.Nickname = nickName
			u.CreateTime = time.Now()
			u.ChannelId = msg.GetChannelId()
			u.Model = msg.GetModel()

			err = domainUser.SaveUser(u)
			if err != nil {
				glog.Info("保存用户失败err:", err, " user:", u)
				res.Code = pb.MsgLoginRes_FAILED.Enum()
				return server.BuildClientMsg(m.GetMsgId(), res)
			}
			onCreatePlayer(player, msg.GetRobotWinTimes(), msg.GetRobotLoseTimes(), msg.GetRobotCurDayEarnGold(), msg.GetRobotCurWeekEarnGold(), msg.GetRobotMaxCards())
		} else {
			// 查找用户失败
			glog.Error("查找用户失败username:", msg.GetUsername(), " err:", err)
			res.Code = pb.MsgLoginRes_FAILED.Enum()
			return server.BuildClientMsg(m.GetMsgId(), res)
		}
	} else {
		// 用户存在，校验密码
		if msg.GetRobotKey() != config.RobotKey && u.Password != genPassword(msg.GetUserpwd()) {
			glog.Info("===>检验密码失败username:", msg.GetUsername(), " pwd:", u.Password, "recvPwd:", genPassword(msg.GetUserpwd()))
			res.Code = pb.MsgLoginRes_USERNAME_OR_PASSWORD_ERROR.Enum()
			return server.BuildClientMsg(m.GetMsgId(), res)
		}
	}

	if u.IsLocked {
		glog.Info("==>userId:", u.UserId, "账号被锁定")
		res.Code = pb.MsgLoginRes_LOCKED.Enum()
		return server.BuildClientMsg(m.GetMsgId(), res)
	}

	glog.V(2).Info("===>登录成功player userId:", player.User.UserId)

	if sess.LoggedIn {
		glog.Info("===>user:", msg.GetUsername(), "已经登录!")
		if sess.OnLogout != nil {
			sess.OnLogout()
		}
	}

	player.SessKey = bson.NewObjectId().Hex()

	if !domainUser.GetPlayerManager().AddItem(player.User.UserId, player.User.IsRobot, sess) {
		glog.Info("===>玩家已在线，踢掉userId:", player.User.UserId, " IP:", sess.IP, " sessKey:", player.SessKey, " sess:", sess)
		msg := &pb.MsgShowTips{}
		msg.Cmd = proto.Int(1)
        msg.UserId = proto.String(player.User.UserId)
        msg.Content = proto.String("您的账号在其他设备登陆，请确认个人账号的安全。")
        msg.Buttons = append(msg.Buttons, "确定")
        msg.Buttons = append(msg.Buttons, "退出")
        domainUser.GetPlayerManager().SendClientMsg(player.User.UserId, int32(pb.MessageId_SHOW_TIPS), msg)

		domainUser.GetPlayerManager().Kickout(player.User.UserId)

		ok := false
		for i := 0; i < 10; i++ {
			time.Sleep(150 * time.Millisecond)
			if !domainUser.GetPlayerManager().AddItem(player.User.UserId, player.User.IsRobot, sess) {
				continue
			}
			ok = true
			break
		}

		glog.Info("===>继续处理登录userId:", player.User.UserId, " ok:", ok, " sessKey:", player.SessKey, " sess:", sess)

		if !ok {
			glog.Info("登录失败，踢出上一玩家失败userId:", player.User.UserId)
			res.Code = pb.MsgLoginRes_FAILED.Enum()
			return server.BuildClientMsg(m.GetMsgId(), res)
		}
	}

	// 加载用户信息
	if !player.OnLogin() {
		domainUser.GetPlayerManager().DelItem(player.User.UserId, player.User.IsRobot)
		glog.Info("userId:", player.User.UserId, " OnLogin失败!")
		res.Code = pb.MsgLoginRes_FAILED.Enum()
		return server.BuildClientMsg(m.GetMsgId(), res)
	}

	glog.Info("==>玩家登录成功userId:", player.User.UserId, " deviceId:", msg.GetDeviceId(), " sessKey:", player.SessKey, " sess:", sess)

	if player.NewPlayer {
		domainUser.GetUserFortuneManager().EarnGold(player.User.UserId, 2000, "新账号")
		player.User.UpgradePrizeVersion = msg.GetVersionName()
	}

	sess.LoggedIn = true
	sess.OnLogout = player.OnLogout
	sess.Data = player
	player.LoginIP = sess.IP
	player.LoginDeviceId = msg.GetDeviceId()

	player.SendToClientFunc = func(msgId int32, body proto.Message) {
		sess.SendToClient(server.BuildClientMsg(int32(msgId), body))
	}
	player.OnLogoutFunc = onLogout

	player.SetUserCache()

	player.SendToClient(int32(pb.MessageId_CHAT), util.BuildSysBugle(fmt.Sprintf("欢迎%v进入游戏！预祝您游戏愉快！加客服QQ：3284317919，领取新手兑换码！", player.User.Nickname)))

	if player.User.IsRobot {
		domainUser.GetFakeRankingList().SetRobot(player.User.UserId)
		domainUser.GetBackgroundUserManager().SetUser(player.User.UserId, true)
	}

	if !player.NewPlayer && !player.User.IsRobot{
	    domainUser.GetUserFortuneManager().CheckVipLevel(player.User.UserId)
	}

	go processOfflineMsg(player.User.UserId)

	glog.Info("===>登录结果:成功userId:", player.User.UserId, " sess:", sess)

	// 登录成功
	res.Code = pb.MsgLoginRes_OK.Enum()
	res.ServerTime = proto.Int64(time.Now().Unix())
	return server.BuildClientMsg(m.GetMsgId(), res)
}

func onCreatePlayer(p *domainUser.GamePlayer, robotWinTimes, robotLoseTimes, robotCurDayEarnGold, robotCurWeekEarnGold int32, robotMaxCards []int32) {
	p.NewPlayer = true

	p.UserLog = &domainUser.UserLog{}
	p.UserLog.UserId = p.User.UserId
	p.UserLog.UserName = p.User.UserName
	p.UserLog.CreateTime = p.User.CreateTime
	p.UserLog.Model = p.User.Model
	p.UserLog.Channel = p.User.ChannelId

	matchRecord := &domainUser.MatchRecord{}
	matchRecord.UserId = p.User.UserId
	matchRecord.WinTimes = int(robotWinTimes)
	matchRecord.LoseTimes = int(robotLoseTimes)
	matchRecord.CurDayEarnGold = int(robotCurDayEarnGold)
	matchRecord.CurWeekEarnGold = int(robotCurWeekEarnGold)
	matchRecord.MaxCards = robotMaxCards
	matchRecord.DayEarnGoldResetTime = time.Now()
	matchRecord.WeekEarnGoldResetTime = time.Now()
	domainUser.SaveMatchRecord(matchRecord)
}

func onLogout(userId string) {
	// 登出
	go domainGame.GetDeskManager().OnOffline(userId)
}

func processOfflineMsg(userId string) {
	msgs, err := offlineMsg.FindOfflineMsg(userId)
	if err != nil {
		return
	}

	for _, msg := range msgs {
		serverMsg := &pb.ServerMsg{}
		err = proto.Unmarshal(msg.MsgBody, serverMsg)
		if err != nil {
			continue
		}
		domainUser.GetPlayerManager().SendServerMsg2("", []string{userId}, msg.MsgId, serverMsg.MsgBody)
	}

}
