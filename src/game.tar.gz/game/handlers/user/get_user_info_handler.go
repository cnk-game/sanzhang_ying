package user

import (
	"code.google.com/p/goprotobuf/proto"
	domainUser "game/domain/user"
	"game/server"
	"pb"
	"util"
)

func GetUserInfoHandler(m *pb.ServerMsg, sess *server.Session) []byte {
	player := domainUser.GetPlayer(sess.Data)

	f, _ := domainUser.GetUserFortuneManager().GetUserFortune(player.User.UserId)
	player.UserTasks.AccomplishTask(util.TaskAccomplishType_GOLD, f.Gold, player.SendToClientFunc)

    if len(f.VipTaskStates) == 0 {
        domainUser.GetUserFortuneManager().InitVipTaskState(player.User.UserId)
    }

	res := &pb.MsgGetUserInfoRes{}
	res.UserInfo = player.User.BuildMessage(player.MatchRecord.BuildMessage())
	res.UserInfo.IsRobot = proto.Bool(false)

	if f.DoubleCardCount > 0 {
		itemMsg := &pb.UserMagicItemDef{}
		itemMsg.ItemType = pb.MagicItemType_FOURFOLD_GOLD.Enum()
		itemMsg.Count = proto.Int(f.DoubleCardCount)
		res.UserInfo.ItemList = append(res.UserInfo.ItemList, itemMsg)
	}

	if f.ForbidCardCount > 0 {
		itemMsg := &pb.UserMagicItemDef{}
		itemMsg.ItemType = pb.MagicItemType_PROHIBIT_COMPARE.Enum()
		itemMsg.Count = proto.Int(f.ForbidCardCount)
		res.UserInfo.ItemList = append(res.UserInfo.ItemList, itemMsg)
	}

	if f.ChangeCardCount > 0 {
		itemMsg := &pb.UserMagicItemDef{}
		itemMsg.ItemType = pb.MagicItemType_REPLACE_CARD.Enum()
		itemMsg.Count = proto.Int(f.ChangeCardCount)
		res.UserInfo.ItemList = append(res.UserInfo.ItemList, itemMsg)
	}

	res.UserInfo.PrizeTaskList = player.UserTasks.BuildMessage2()
	res.UserInfo.OnlinePrizeList = player.OnlinePrizeGainRecords.BuildMessage()

	return server.BuildClientMsg(m.GetMsgId(), res)
}
