package main

import (
	"config"
	"flag"
	"game/domain/game"
	domainPrize "game/domain/prize"
	"game/domain/randBugle"
	"game/domain/rankingList"
	"game/domain/slots"
	"game/domain/stats"
	"game/domain/user"
	domainUser "game/domain/user"
	"game/handlers"
	"game/server"
	"github.com/golang/glog"
	"os"
	"os/signal"
	"runtime"
	"syscall"
	"time"
	domainSlot "game/domain/slots"
	forbidWords "game/domain/forbidWords"
	domainPay "game/domain/pay"
)

func main() {
	flag.Parse()
	glog.Info("===>启动游戏服务器")

	initialize()

	runtime.GOMAXPROCS(runtime.NumCPU())

	go stopHandler(server.GetServerInstance().GetSigChan())

	server.GetServerInstance().StartServer(handlers.GetMsgRegistry())
}

func stopHandler(c chan os.Signal) {
	signal.Notify(c, syscall.SIGTERM, syscall.SIGINT, syscall.SIGKILL)
	<-c

	rankingList.GetRankingList().Save()
	domainUser.GetRankingListUpdater().DoUpdate()
	stats.GetMatchLogManager().SaveAllMatchLogs()
	stats.GetAiFortuneLogManager().SaveLog()

	server.GetServerInstance().SetRefuseService()
	server.GetServerInstance().WaitStopServer()
	glog.Flush()
	os.Exit(0)
}

func initialize() {
	config.GetConfigManager().Init()
	config.GetCardConfigManager().Init()
	config.GetVipPriceConfigManager().Init()
	domainPrize.GetOnlinePrizeManager().Init()
	domainPrize.GetVipPrizeManager().Init()
	domainPrize.GetTaskPrizeManager().Init()
	domainPrize.GetExchangeGoodsManager().Init()
	slots.GetWheelConfigManager().Init()
	stats.GetMatchLogManager().Init()
	stats.GetAiFortuneLogManager().Init()
	domainSlot.Init()
	forbidWords.InitForbidWords()
	domainPay.Init()

	user.GetUserFortuneManager().UpdateGoldInGameFunc = game.GetDeskManager().UpdateGoldInGame

	rankingList.GetRankingList().Init()
	randBugle.GetRandBugleManager().Init()

	saveOnlineLog()
}

func saveOnlineLog() {
	go func() {
		for {
			stats.SaveOnlineLog(domainUser.GetPlayerManager().GetOnlineCount())
			time.Sleep(5 * time.Minute)
		}
	}()
}

