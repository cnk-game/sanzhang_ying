package pay

import (
	mgo "gopkg.in/mgo.v2"
	"time"
	"util"
)

type PayLog struct {
	OrderId    string    `bson:"orderId"`
	UserId     string    `bson:"userId"`
	Amount     int       `bson:"amount"`
	PayChannel string    `bson:"payChannel"`
	PayType    string    `bson:"payType"`
	Channel    string    `bson:"channel"`
	Time       time.Time `bson:"time"`
}

const (
	payLogC = "pay_log"
)

func SavePayLog(log *PayLog) error {
	log.Time = time.Now()
	return util.WithLogCollection(payLogC, func(c *mgo.Collection) error {
		return c.Insert(log)
	})
}
