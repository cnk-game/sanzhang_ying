package pay

import (
	"github.com/golang/glog"
	"time"
	"fmt"
	"sync"
	"crypto/md5"
	"io"
)

type TokenManager struct {
	sync.RWMutex
	tokens          map[string]string
}

var tokenManager *TokenManager

func Init() {
    tokenManager = &TokenManager{}
    tokenManager.tokens = make(map[string]string)
}

func GetTokenManager() *TokenManager {
    return tokenManager
}

func (this *TokenManager)GetToken(userId string) string {
    this.Lock()
    defer this.Unlock()

    tm := time.Now()
    sign := "QF" + userId + fmt.Sprintf("%d-%d-%d %02d:%02d:%02d",tm.Year(), tm.Month(), tm.Day(), tm.Hour(), tm.Minute(), tm.Second())
    token := Md5func(sign)

    this.tokens[token] = userId

    return token
}

func (this *TokenManager)CheckToken(token string) (bool, string) {
    this.Lock()
    defer this.Unlock()

    uId, ok := this.tokens[token]
    if !ok {
        glog.Info("CheckToken filed, token=", token)
        return false, ""
    }
    delete(this.tokens,token)

    return true, uId
}

func Md5func(s string) string {
	h := md5.New()
	io.WriteString(h, s)
	return fmt.Sprintf("%x", h.Sum(nil))
}