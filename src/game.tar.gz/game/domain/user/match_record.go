package user

import (
	"code.google.com/p/goprotobuf/proto"
	"github.com/golang/glog"
	mgo "gopkg.in/mgo.v2"
	"gopkg.in/mgo.v2/bson"
	"pb"
	"time"
	"util"
)

type MatchRecord struct {
	UserId                string    `bson:"userId"`
	WinTimes              int       `bson:"winTimes"`
	LoseTimes             int       `bson:"loseTimes"`
	CurDayEarnGold        int       `bson:"curDayEarnGold"`
	CurWeekEarnGold       int       `bson:"curWeekEarnGold"`
	MaxCards              []int32   `bson:"maxCards"`
	DayEarnGoldResetTime  time.Time `bson:"dayEarnGoldResetTime"`
	WeekEarnGoldResetTime time.Time `bson:"weekEarnGoldResetTime"`
}

func (r *MatchRecord) BuildMessage() *pb.UserMatchRecordDef {
	r.resetEarnGold()

	msg := &pb.UserMatchRecordDef{}
	msg.PlayWinCount = proto.Int(r.WinTimes)
	msg.PlayTotalCount = proto.Int(r.WinTimes + r.LoseTimes)
	msg.TheDayWinGold = proto.Int(r.CurDayEarnGold)
	msg.TheWeekWinGold = proto.Int(r.CurWeekEarnGold)
	msg.MaxCards = r.MaxCards

	return msg
}

func (r *MatchRecord) resetEarnGold() {
	now := time.Now()
	if !util.CompareDate(now, r.DayEarnGoldResetTime) {
		r.CurDayEarnGold = 0
		r.DayEarnGoldResetTime = now
	}

	if !util.CompareDate(now, r.WeekEarnGoldResetTime) && now.Weekday() == time.Monday {
		r.CurWeekEarnGold = 0
		r.WeekEarnGoldResetTime = now
	}
}

func (r *MatchRecord) AddEarnGold(gold int) {
	r.resetEarnGold()
	r.CurDayEarnGold += gold
	r.CurWeekEarnGold += gold
}

const (
	matchRecordC = "match_record"
)

func FindMatchRecord(userId string) *MatchRecord {
	r := &MatchRecord{}
	r.UserId = userId
	err := util.WithUserCollection(matchRecordC, func(c *mgo.Collection) error {
		return c.Find(bson.M{"userId": userId}).One(r)
	})
	if err != nil {
		glog.Error("加载玩家比赛记录失败err:", err)
	}
	return r
}

func SaveMatchRecord(r *MatchRecord) error {
	return util.WithSafeUserCollection(matchRecordC, func(c *mgo.Collection) error {
		_, err := c.Upsert(bson.M{"userId": r.UserId}, r)
		return err
	})
}
