package user

import (
	mgo "gopkg.in/mgo.v2"
	"time"
	"util"
	"gopkg.in/mgo.v2/bson"
)

type FortuneLog struct {
	UserId     string    `bson:"userId"`
	Gold       int       `bson:"gold"`
	CurGold    int64     `bson:"curGold"`
	Diamond    int       `bson:"diamond"`
	CurDiamond int       `bson:"curDiamond"`
	Score      int       `bson:"score"`
	CurScore   int       `bson:"curScore"`
	Reason     string    `bson:"reason"`
	Time       time.Time `bson:"time"`
}

type GiftFishLog struct {
	FromId     string    `bson:"fromId"`
	ToId       string    `bson:"toId"`
	FishType   int       `bson:"fishType"`
	Count      int       `bson:"count"`
	Time       time.Time `bson:"time"`
}

const (
	earnFortuneLogC    = "earn_fortune"
	consumeFortuneLogC = "consume_fortune"
	giftFishLogC = "gift_fish"
)

func FindEarnFortuneLogs() ([]*FortuneLog, error) {
	logs := []*FortuneLog{}
	err := util.WithLogCollection(earnFortuneLogC, func(c *mgo.Collection) error {
		return c.Find(nil).All(&logs)
	})

	return logs, err
}

func SaveEarnFortuneLog(log *FortuneLog) error {
	log.Time = time.Now()
	return util.WithLogCollection(earnFortuneLogC, func(c *mgo.Collection) error {
		return c.Insert(log)
	})
}

func SaveGiftFishLog(fromId, toId string, fishType, count int) error {
	log := GiftFishLog{fromId, toId, fishType, count, time.Now()}
	return util.WithLogCollection(giftFishLogC, func(c *mgo.Collection) error {
		return c.Insert(log)
	})
}

func LoadGiftFishLog(userId string) ([]*GiftFishLog, error) {
	logs := []*GiftFishLog{}
	err := util.WithLogCollection(giftFishLogC, func(c *mgo.Collection) error {
		return c.Find(bson.M{"fromId":userId}).All(&logs)
	})
	return logs, err
}

func FindConsumeFortuneLogs() ([]*FortuneLog, error) {
	logs := []*FortuneLog{}
	err := util.WithLogCollection(consumeFortuneLogC, func(c *mgo.Collection) error {
		return c.Find(nil).All(&logs)
	})

	return logs, err
}

func SaveConsumeFortuneLog(log *FortuneLog) error {
	log.Time = time.Now()
	return util.WithLogCollection(consumeFortuneLogC, func(c *mgo.Collection) error {
		return c.Insert(log)
	})
}
