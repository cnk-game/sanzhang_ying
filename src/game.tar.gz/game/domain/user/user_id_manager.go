package user

import (
	"gopkg.in/mgo.v2/bson"
	mgo "gopkg.in/mgo.v2"
	"util"
	"strconv"
	"github.com/golang/glog"
)

const (
	userIdC = "user_id_index"
)

type sequence struct {
	Name string    `bson:"name"`
	Val  int64     `bson:"seq"`
}


func GetNewUserId() string {
    ch := mgo.Change{
		Update:    bson.M{"$inc": bson.M{"seq": 1}},
		ReturnNew: true,
	}

	next := &sequence{}
	err := util.WithUserCollection(userIdC, func(c *mgo.Collection) error {
		_, err := c.Find(bson.M{"name": "index"}).Apply(ch, &next)
		return err
	})

	if err != nil {
		return "error"
	}

    glog.Info("GetNewUserId in. next=",next)
	newId := "QF" + strconv.Itoa(int(next.Val))

	return newId
}